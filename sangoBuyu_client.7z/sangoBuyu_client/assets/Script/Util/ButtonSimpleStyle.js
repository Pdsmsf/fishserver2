const ButtonSimpleStyle = {
    BLUE: cc.Enum({
        atlasUrl: "Atlas/icon",
        spriteNormalName: "btn_anniu",
        spritePressName: "btn_anniuanxia",
        spriteDisabledName: "btn_anniuhui"
    }),
    BACK: cc.Enum({
        atlasUrl: "Atlas/icon",
        spriteNormalName: "btn_fanhuianniu",
        spritePressName: "btn_fanhuianniuanxia",
        spriteDisabledName: "btn_fanhuianniuhui"
    }),
};
export default ButtonSimpleStyle;